import java.util.Stack;

public class BalancedBrackets {
    public static void main(String[] args) {
        String s ="{()}[]";
        char charArray[] = s.toCharArray();

        Stack<Character> stack = new Stack<>();


        for(int i =0; i<s.length();i++){
            if(stack.empty()){
                stack.push(charArray[i]);
            }
            else if((stack.peek()=='(' && charArray[i]==')') ||
                    (stack.peek()=='{' && charArray[i]=='}') ||
                    (stack.peek()=='[' && charArray[i]==']')){
                stack.pop();
            }

            else {
                stack.push(charArray[i]);
            }
        }
        if(s.length() > 0) {
            if (stack.empty()) {
                System.out.println("correct order");
            } else {
                System.out.println("incorrect order");
            }
        }
        else
        {
            System.out.println("please initialize string to check format of the string");
        }
    }
}
